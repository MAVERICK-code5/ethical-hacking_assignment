#include <stdio.h>
#include <string.h>

int main() {
    char buffer[16];  // Buffer of size 16
    char input[100];  // Larger input buffer

    printf("Enter some text: ");
    scanf("%s", input);  // Read user input

    // Unsafe copy (no bounds checking)
    strcpy(buffer, input);

    printf("Buffer content: %s\n", buffer);

    return 0;
}

//////////////////////
/*
1. What happens with long input?

    If the user enters more than 16 characters (e.g., 30+),
    strcpy() will copy all data into 'buffer' without checking size.
    This causes a buffer overflow, overwriting adjacent memory.

2. Why is this dangerous?

- It can overwrite important data in memory.
- It may crash the program (segmentation fault).
- Attackers can exploit this to execute arbitrary code
  (e.g., overwrite return addresses → classic stack overflow attack).

3. How would you fix it?
  Use strncpy()
    strncpy(buffer, input, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\0'; 
