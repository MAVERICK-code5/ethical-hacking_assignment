#!/usr/bin/env python3

import socket
import time

def scan_ports(target, ports):
    results = []
    
    print(f"Starting scan on {target}...\n")
    
    start_time = time.time()

    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)

        result = sock.connect_ex((target, port))

        if result == 0:
            status = "OPEN"
        else:
            status = "CLOSED"

        print(f"Port {port}: {status}")
        results.append((port, status))

        sock.close()

    end_time = time.time()
    duration = end_time - start_time

    return results, duration


def save_results(target, results, duration):
    with open("scan_results.txt", "w") as f:
        f.write(f"Scan Results for {target}\n")
        f.write("-" * 30 + "\n")

        for port, status in results:
            f.write(f"Port {port}: {status}\n")

        f.write("-" * 30 + "\n")
        f.write(f"Scan Duration: {duration:.2f} seconds\n")


def main():
    target = input("Enter target IP: ")
    port_input = input("Enter ports (comma-separated, e.g., 21,22,80): ")

    try:
        ports = [int(p.strip()) for p in port_input.split(",")]
    except ValueError:
        print("Invalid port list.")
        return

    results, duration = scan_ports(target, ports)
    save_results(target, results, duration)

    print("\nScan completed.")
    print(f"Results saved to scan_results.txt")
    print(f"Scan duration: {duration:.2f} seconds")


if __name__ == "__main__":
    main()