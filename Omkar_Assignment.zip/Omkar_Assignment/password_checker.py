#!/usr/bin/env python3

import re

def check_password_strength(password):
    score = 0
    recommendations = []

    # Length check
    if len(password) >= 8:
        score += 1
    else:
        recommendations.append("Use at least 8 characters.")

    # Uppercase check
    if re.search(r"[A-Z]", password):
        score += 1
    else:
        recommendations.append("Add at least one uppercase letter.")

    # Lowercase check
    if re.search(r"[a-z]", password):
        score += 1
    else:
        recommendations.append("Add at least one lowercase letter.")

    # Number check
    if re.search(r"[0-9]", password):
        score += 1
    else:
        recommendations.append("Include at least one number.")

    # Special character check
    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        score += 1
    else:
        recommendations.append("Include at least one special character.")

    # Strength classification
    if score <= 2:
        strength = "Weak"
    elif score <= 4:
        strength = "Medium"
    else:
        strength = "Strong"

    return score, strength, recommendations


def main():
    password = input("Enter password: ")

    score, strength, recommendations = check_password_strength(password)

    print("\n--- Password Strength Report ---")
    print(f"Score: {score}/5")
    print(f"Strength: {strength}")

    if recommendations:
        print("\nRecommendations:")
        for rec in recommendations:
            print(f"- {rec}")
    else:
        print("\nExcellent! Your password meets all criteria.")


if __name__ == "__main__":
    main()