#!/bin/bash

# Check if target IP is provided
if [ -z "$1" ]; then
    echo "Usage: $0 <target_ip>"
    exit 1
fi

TARGET=$1
DATE=$(date +%Y-%m-%d)
OUTPUT="scan_${TARGET}_${DATE}.txt"

# Common ports to scan
PORTS=(21 22 80 443 3306)

echo "Scanning target: $TARGET" > "$OUTPUT"
echo "Scan date: $DATE" >> "$OUTPUT"
echo "---------------------------------" >> "$OUTPUT"

OPEN_COUNT=0

# Scan ports
for PORT in "${PORTS[@]}"; do
    timeout 1 bash -c "echo >/dev/tcp/$TARGET/$PORT" 2>/dev/null

    if [ $? -eq 0 ]; then
        echo "Port $PORT: OPEN" | tee -a "$OUTPUT"
        ((OPEN_COUNT++))
    else
        echo "Port $PORT: CLOSED" >> "$OUTPUT"
    fi
done

echo "---------------------------------" >> "$OUTPUT"
echo "Total open ports: $OPEN_COUNT" | tee -a "$OUTPUT"

echo "Scan results saved to $OUTPUT"chmod +x port_report.sh